from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup as soup

# Set up options for WebDriver
options = Options()
options.set_preference("network.cookie.cookieBehavior", 0)
# Uncomment the next line if you want the browser to be headless
# options.add_argument("--headless")

# Set up the WebDriver service
service = Service(GeckoDriverManager().install())

# Initialize the WebDriver
driver = webdriver.Firefox(service=service, options=options)

amos_page = "https://swiss-as.com"

# Navigate to a website
driver.get(amos_page)

tab = driver.find_element(By.XPATH, "/html/body/div[1]/div/div[2]/div[1]/header/nav/div[2]/ul/li[2]/a")
tab.click()

username_field = driver.find_element(By.ID, "username")
username_field.send_keys("dlh_u734409")

password_field = driver.find_element(By.ID, "password")
password_field.send_keys("Rayan1304!")

login_button = driver.find_element(By.ID, "kc-login")
login_button.click()

change_tracker_xp = driver.find_element(By.XPATH, "/html/body/div[2]/div[3]/div[2]/div/ul/li[1]/a")
change_tracker_xp.click()

from_version = "23.12"
to_version = "24.6-preview6"

from_version_field = driver.find_element(By.ID, "filterVersionFrom")
from_version_field.clear()
from_version_field.send_keys(from_version)

to_version_field = driver.find_element(By.ID, "filterVersionTo")
to_version_field.send_keys(to_version)

submit_filter = driver.find_element(By.XPATH, "/html/body/div[2]/div[3]/div[2]/div/form/table/tbody/tr[2]/td[5]/input[1]")
submit_filter.click()

wait = WebDriverWait(driver, 10)  # Timeout of 10 seconds
element = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/div[2]/div[3]/div[2]/div/div[1]/div/h1")))

page_source = driver.page_source
#----
soup_instance = soup(page_source, 'html.parser')

result_container = soup_instance.find('div', id='resultContainer')

# Find the h3 element (the title) within the div
# Find the h3 element (the title) within the div
title = result_container.find('h3') if result_container else None

# Find the content associated with the title
# This might need to be adjusted depending on the actual HTML structure
content = title.find_next_sibling() if title else None

title_text = title.get_text(strip=True) if title else "Title not found"
content_html = str(content) if content else "Content not found"

# Creating an HTML document with extracted content
html_document = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Extracted Data</title>
</head>
<body>
    <h1>Title:</h1>
    <div>{title_text}</div>
    
    <h1>Content:</h1>
    {content_html}
</body>
</html>
"""

# Writing to an HTML file
with open('extracted_data.html', 'w', encoding='utf-8') as file:
    file.write(html_document)
